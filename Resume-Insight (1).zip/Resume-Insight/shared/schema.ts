import { sql } from "drizzle-orm";
import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ==============================
// Resume Analyzer
// ==============================

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  resumeText: text("resume_text").notNull(),
  jobTitle: text("job_title").notNull().default(""),
  jobDescription: text("job_description").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resumeAnalyses = pgTable("resume_analyses", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id")
    .notNull()
    .references(() => resumes.id, { onDelete: "cascade" }),
  overallScore: integer("overall_score").notNull(),
  summary: text("summary").notNull(),
  strengths: text("strengths").array().notNull().default(sql`'{}'::text[]`),
  gaps: text("gaps").array().notNull().default(sql`'{}'::text[]`),
  improvements: text("improvements").array().notNull().default(sql`'{}'::text[]`),
  atsKeywords: text("ats_keywords").array().notNull().default(sql`'{}'::text[]`),
  missingKeywords: text("missing_keywords").array().notNull().default(sql`'{}'::text[]`),
  redFlags: text("red_flags").array().notNull().default(sql`'{}'::text[]`),
  sectionsScore: jsonb("sections_score").$type<Record<string, number>>().notNull().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResumeSchema = createInsertSchema(resumes).omit({
  id: true,
  createdAt: true,
});

export const insertResumeAnalysisSchema = createInsertSchema(resumeAnalyses).omit({
  id: true,
  createdAt: true,
});

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;

export type ResumeAnalysis = typeof resumeAnalyses.$inferSelect;
export type InsertResumeAnalysis = z.infer<typeof insertResumeAnalysisSchema>;

export type CreateResumeRequest = InsertResume;
export type UpdateResumeRequest = Partial<InsertResume>;

export type AnalyzeResumeRequest = {
  resumeText: string;
  jobTitle?: string;
  jobDescription?: string;
};

export type ResumeResponse = Resume;
export type ResumeListResponse = Resume[];

export type ResumeAnalysisResponse = ResumeAnalysis;

export type ResumeAnalysisResult = {
  overallScore: number;
  summary: string;
  strengths: string[];
  gaps: string[];
  improvements: string[];
  atsKeywords: string[];
  missingKeywords: string[];
  redFlags: string[];
  sectionsScore: Record<string, number>;
};
