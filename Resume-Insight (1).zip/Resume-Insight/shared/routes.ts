import { z } from "zod";
import { insertResumeSchema } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const sectionsScoreSchema = z.record(z.string(), z.number().int().min(0).max(100));

export const resumeAnalysisResultSchema = z.object({
  overallScore: z.number().int().min(0).max(100),
  summary: z.string(),
  strengths: z.array(z.string()),
  gaps: z.array(z.string()),
  improvements: z.array(z.string()),
  atsKeywords: z.array(z.string()),
  missingKeywords: z.array(z.string()),
  redFlags: z.array(z.string()),
  sectionsScore: sectionsScoreSchema,
});

export const api = {
  resumes: {
    list: {
      method: "GET" as const,
      path: "/api/resumes",
      input: z
        .object({
          search: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.array(
          z.object({
            id: z.number().int(),
            title: z.string(),
            resumeText: z.string(),
            jobTitle: z.string(),
            jobDescription: z.string(),
            createdAt: z.string().or(z.date()),
          })
        ),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/resumes/:id",
      responses: {
        200: z.object({
          id: z.number().int(),
          title: z.string(),
          resumeText: z.string(),
          jobTitle: z.string(),
          jobDescription: z.string(),
          createdAt: z.string().or(z.date()),
        }),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/resumes",
      input: insertResumeSchema.extend({
        title: z.string().min(1, "Title is required"),
        resumeText: z.string().min(50, "Paste a longer resume text"),
      }),
      responses: {
        201: z.object({
          id: z.number().int(),
          title: z.string(),
          resumeText: z.string(),
          jobTitle: z.string(),
          jobDescription: z.string(),
          createdAt: z.string().or(z.date()),
        }),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: "PATCH" as const,
      path: "/api/resumes/:id",
      input: insertResumeSchema.partial(),
      responses: {
        200: z.object({
          id: z.number().int(),
          title: z.string(),
          resumeText: z.string(),
          jobTitle: z.string(),
          jobDescription: z.string(),
          createdAt: z.string().or(z.date()),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/resumes/:id",
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    analyze: {
      method: "POST" as const,
      path: "/api/resumes/:id/analyze",
      input: z
        .object({
          jobTitle: z.string().optional(),
          jobDescription: z.string().optional(),
        })
        .optional(),
      responses: {
        201: z.object({
          id: z.number().int(),
          resumeId: z.number().int(),
          overallScore: z.number().int().min(0).max(100),
          summary: z.string(),
          strengths: z.array(z.string()),
          gaps: z.array(z.string()),
          improvements: z.array(z.string()),
          atsKeywords: z.array(z.string()),
          missingKeywords: z.array(z.string()),
          redFlags: z.array(z.string()),
          sectionsScore: sectionsScoreSchema,
          createdAt: z.string().or(z.date()),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    latestAnalysis: {
      method: "GET" as const,
      path: "/api/resumes/:id/analyses/latest",
      responses: {
        200: z.object({
          id: z.number().int(),
          resumeId: z.number().int(),
          overallScore: z.number().int().min(0).max(100),
          summary: z.string(),
          strengths: z.array(z.string()),
          gaps: z.array(z.string()),
          improvements: z.array(z.string()),
          atsKeywords: z.array(z.string()),
          missingKeywords: z.array(z.string()),
          redFlags: z.array(z.string()),
          sectionsScore: sectionsScoreSchema,
          createdAt: z.string().or(z.date()),
        }),
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>
): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type ResumeCreateInput = z.infer<typeof api.resumes.create.input>;
export type ResumeResponse = z.infer<typeof api.resumes.get.responses[200]>;
export type ResumeListResponse = z.infer<typeof api.resumes.list.responses[200]>;
export type ResumeUpdateInput = z.infer<typeof api.resumes.update.input>;
export type ResumeAnalysisResponse = z.infer<typeof api.resumes.analyze.responses[201]>;
export type ResumeAnalysisResult = z.infer<typeof resumeAnalysisResultSchema>;
