import { useState } from "react";
import { Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export function CopyButton({
  text,
  label = "Copy",
  testId,
  size = "sm",
}: {
  text: string;
  label?: string;
  testId: string;
  size?: "sm" | "default";
}) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast({ title: "Copied", description: "Copied to clipboard." });
      window.setTimeout(() => setCopied(false), 1200);
    } catch (e) {
      toast({
        title: "Copy failed",
        description: e instanceof Error ? e.message : "Clipboard not available.",
        variant: "destructive",
      });
    }
  }

  return (
    <Button
      type="button"
      size={size}
      variant="secondary"
      data-testid={testId}
      onClick={handleCopy}
      className="rounded-xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium"
    >
      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      <span className="ml-2">{copied ? "Copied" : label}</span>
    </Button>
  );
}
