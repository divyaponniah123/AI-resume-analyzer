import { useEffect } from "react";

export default function Seo({
  title,
  description,
}: {
  title: string;
  description?: string;
}) {
  useEffect(() => {
    document.title = title;
    if (!description) return;

    const name = "description";
    const existing = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
    if (existing) {
      existing.content = description;
      return;
    }
    const meta = document.createElement("meta");
    meta.name = name;
    meta.content = description;
    document.head.appendChild(meta);

    return () => {
      // keep meta in place across routes; do nothing
    };
  }, [title, description]);

  return null;
}
