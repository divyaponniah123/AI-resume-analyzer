import { PropsWithChildren, useMemo } from "react";
import { Link, useLocation } from "wouter";
import {
  Sparkles,
  LayoutList,
  Plus,
  Moon,
  Sun,
  Github,
  ScanSearch,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function useTheme() {
  const isDark = useMemo(() => document.documentElement.classList.contains("dark"), []);
  return { isDark };
}

function setTheme(next: "dark" | "light") {
  const root = document.documentElement;
  if (next === "dark") root.classList.add("dark");
  else root.classList.remove("dark");
  try {
    localStorage.setItem("theme", next);
  } catch {
    // ignore
  }
}

export function initTheme() {
  try {
    const stored = localStorage.getItem("theme");
    if (stored === "dark" || stored === "light") {
      setTheme(stored);
      return;
    }
  } catch {
    // ignore
  }
  // Prefer system
  const prefersDark = window.matchMedia?.("(prefers-color-scheme: dark)")?.matches;
  setTheme(prefersDark ? "dark" : "light");
}

function NavLink({
  href,
  icon: Icon,
  label,
  active,
  testId,
}: {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active: boolean;
  testId: string;
}) {
  return (
    <Link
      href={href}
      data-testid={testId}
      className={cn(
        "tap-highlight-none inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-all duration-300 ease-out ring-focus",
        active
          ? "bg-foreground text-background shadow-sm"
          : "text-foreground/70 hover:text-foreground hover:bg-muted/70",
      )}
    >
      <Icon className={cn("h-4 w-4", active ? "opacity-100" : "opacity-70")} />
      <span className="hidden sm:inline">{label}</span>
    </Link>
  );
}

export default function AppShell({ children }: PropsWithChildren) {
  const [loc] = useLocation();
  const isResumes = loc === "/" || loc.startsWith("/resumes");
  const isNew = loc === "/resumes/new";

  const themeNow = useTheme();

  return (
    <div className="min-h-screen bg-mesh grain">
      <header className="sticky top-0 z-40 border-b bg-background/70 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Link
                href="/"
                data-testid="nav-home"
                className="group inline-flex items-center gap-2 rounded-2xl px-2 py-2 ring-focus"
              >
                <img src="/logo.png" alt="Prism Resume Logo" className="h-9 w-9 rounded-2xl object-cover shadow-premium transition-transform duration-300 ease-out group-hover:-translate-y-0.5" />
                <div className="leading-tight">
                  <div className="text-sm font-semibold text-foreground">Prism Resume</div>
                  <div className="text-xs text-muted-foreground">AI Analyzer</div>
                </div>
              </Link>

              <div className="hidden md:flex items-center gap-2 rounded-2xl border bg-card/70 px-2 py-2 shadow-sm">
                <NavLink
                  href="/"
                  icon={LayoutList}
                  label="Resumes"
                  active={isResumes && !isNew}
                  testId="nav-resumes"
                />
                <NavLink href="/resumes/new" icon={Plus} label="New" active={isNew} testId="nav-new" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link
                href="/resumes/new"
                data-testid="header-new-resume"
                className={cn(
                  "md:hidden inline-flex items-center justify-center rounded-xl border bg-card px-3 py-2 text-sm font-semibold shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-premium ring-focus",
                )}
              >
                <Plus className="h-4 w-4" />
                <span className="ml-2">New</span>
              </Link>

              <Button
                variant="secondary"
                data-testid="toggle-theme"
                onClick={() => {
                  const next = document.documentElement.classList.contains("dark") ? "light" : "dark";
                  setTheme(next);
                }}
                className="rounded-xl shadow-sm hover:shadow-premium transition-all duration-300"
              >
                {themeNow.isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                <span className="ml-2 hidden sm:inline">Theme</span>
              </Button>

              <a
                href="https://github.com/"
                target="_blank"
                rel="noreferrer"
                data-testid="external-github"
                className="hidden sm:inline-flex items-center gap-2 rounded-xl border bg-card px-3 py-2 text-sm font-semibold text-foreground/80 shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-premium hover:text-foreground ring-focus"
              >
                <Github className="h-4 w-4" />
                <span>Repo</span>
              </a>

              <div className="hidden md:flex items-center gap-2 rounded-2xl border bg-card/70 px-3 py-2 shadow-sm">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-xs font-semibold text-muted-foreground">Clean minimal • ATS aware</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="py-6 md:py-10 animate-in-soft">{children}</div>
      </main>

      <footer className="border-t bg-background/60 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-2 py-6 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
            <div className="text-balance">
              Built for fast iteration: paste a resume, target a role, get a sharp analysis.
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-flex h-2 w-2 rounded-full bg-primary/80 shadow-[0_0_0_6px_hsl(var(--primary)/0.10)]" />
              <span data-testid="footer-status" className="font-medium">
                Ready
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
