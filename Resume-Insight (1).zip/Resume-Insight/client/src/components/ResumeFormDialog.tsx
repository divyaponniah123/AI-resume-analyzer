import { useEffect, useMemo } from "react";
import { z } from "zod";
import { api } from "@shared/routes";
import type { CreateResumeRequest, UpdateResumeRequest, Resume } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Sparkles, Save } from "lucide-react";

const createSchema = api.resumes.create.input;
type CreateValues = z.infer<typeof createSchema>;

const updateSchema = api.resumes.update.input.extend({
  title: z.string().min(1, "Title is required").optional(),
});
type UpdateValues = z.infer<typeof updateSchema>;

export function ResumeFormDialog({
  open,
  onOpenChange,
  mode,
  initial,
  onCreate,
  onUpdate,
  isPending,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "create" | "edit";
  initial?: Resume | null;
  onCreate: (values: CreateResumeRequest) => void;
  onUpdate: (values: UpdateResumeRequest) => void;
  isPending?: boolean;
}) {
  const title = mode === "create" ? "New resume" : "Edit resume";
  const description =
    mode === "create"
      ? "Paste the resume text and optionally a job target. You can run analysis anytime."
      : "Refine the resume content or target role—then re-run analysis.";

  const defaultValues = useMemo(() => {
    if (mode === "create") {
      const v: CreateValues = {
        title: "",
        resumeText: "",
        jobTitle: "",
        jobDescription: "",
      };
      return v;
    }
    const v: UpdateValues = {
      title: initial?.title ?? "",
      resumeText: initial?.resumeText ?? "",
      jobTitle: initial?.jobTitle ?? "",
      jobDescription: initial?.jobDescription ?? "",
    };
    return v;
  }, [mode, initial]);

  const form = useForm<CreateValues | UpdateValues>({
    resolver: zodResolver(mode === "create" ? createSchema : updateSchema),
    defaultValues: defaultValues as any,
    mode: "onChange",
  });

  useEffect(() => {
    form.reset(defaultValues as any);
  }, [defaultValues, form]);

  const submit = (values: any) => {
    if (mode === "create") onCreate(values as CreateResumeRequest);
    else onUpdate(values as UpdateResumeRequest);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-3xl border bg-card/80 p-0 shadow-premium-lg backdrop-blur-xl">
        <div className="p-6 md:p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl">{title}</DialogTitle>
            <DialogDescription className="text-balance">{description}</DialogDescription>
          </DialogHeader>

          <div className="mt-6">
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(submit)}
                className="space-y-5"
                data-testid={mode === "create" ? "resume-create-form" : "resume-edit-form"}
              >
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input
                          data-testid={mode === "create" ? "input-title-create" : "input-title-edit"}
                          placeholder="e.g., Senior Product Designer — v3"
                          className="rounded-xl border-2 bg-background/60 focus-visible:ring-4 focus-visible:ring-ring/15"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="resumeText"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Resume text</FormLabel>
                      <FormControl>
                        <Textarea
                          data-testid={mode === "create" ? "input-resumeText-create" : "input-resumeText-edit"}
                          placeholder="Paste your resume text here…"
                          className="min-h-[180px] rounded-xl border-2 bg-background/60 leading-relaxed focus-visible:ring-4 focus-visible:ring-ring/15"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                      <p className="text-xs text-muted-foreground">
                        Tip: include measurable impact (metrics, scope, scale). It improves scoring.
                      </p>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="jobTitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target job title (optional)</FormLabel>
                        <FormControl>
                          <Input
                            data-testid={mode === "create" ? "input-jobTitle-create" : "input-jobTitle-edit"}
                            placeholder="e.g., ML Engineer"
                            className="rounded-xl border-2 bg-background/60 focus-visible:ring-4 focus-visible:ring-ring/15"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="rounded-2xl border bg-muted/40 p-4">
                    <div className="flex items-start gap-2">
                      <Sparkles className="mt-0.5 h-4 w-4 text-primary" />
                      <div>
                        <div className="text-sm font-semibold">ATS alignment</div>
                        <div className="mt-1 text-xs text-muted-foreground text-balance">
                          Add the job description to unlock missing keywords + red flags detection.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="jobDescription"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job description (optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          data-testid={mode === "create" ? "input-jobDescription-create" : "input-jobDescription-edit"}
                          placeholder="Paste the job description…"
                          className="min-h-[140px] rounded-xl border-2 bg-background/60 leading-relaxed focus-visible:ring-4 focus-visible:ring-ring/15"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex flex-col-reverse gap-3 pt-2 md:flex-row md:items-center md:justify-between">
                  <Button
                    type="button"
                    variant="secondary"
                    data-testid={mode === "create" ? "btn-cancel-create" : "btn-cancel-edit"}
                    onClick={() => onOpenChange(false)}
                    className="rounded-xl"
                  >
                    Cancel
                  </Button>

                  <Button
                    type="submit"
                    data-testid={mode === "create" ? "btn-submit-create" : "btn-submit-edit"}
                    disabled={isPending}
                    className="rounded-xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg transition-all duration-300"
                  >
                    <Save className="h-4 w-4" />
                    <span className="ml-2">{isPending ? "Saving…" : mode === "create" ? "Create resume" : "Save changes"}</span>
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>

        <div className="hairline h-px w-full" />
        <div className="px-6 py-4 text-xs text-muted-foreground md:px-8">
          Your data stays in your workspace. Analyses are generated per resume to compare iterations.
        </div>
      </DialogContent>
    </Dialog>
  );
}
