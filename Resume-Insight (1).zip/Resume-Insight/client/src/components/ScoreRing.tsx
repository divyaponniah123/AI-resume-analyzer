import { cn } from "@/lib/utils";

function scoreTone(score: number) {
  if (score >= 85) return "good";
  if (score >= 70) return "warn";
  if (score >= 0) return "bad";
  return "neutral";
}

export function ScoreRing({
  score,
  caption,
  size = 150,
  "data-testid": dataTestId,
}: {
  score: number;
  caption?: string;
  size?: number;
  "data-testid"?: string;
}) {
  const r = 56;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score));
  const dash = (pct / 100) * c;

  const tone = scoreTone(score);
  const color =
    tone === "good"
      ? "hsl(146 60% 40%)"
      : tone === "warn"
        ? "hsl(36 92% 55%)"
        : "hsl(0 84% 58%)";

  return (
    <div
      data-testid={dataTestId}
      className="relative grid place-items-center rounded-3xl border bg-card/70 p-6 shadow-premium hover-lift"
      style={{ width: size, height: size }}
    >
      <svg width={140} height={140} viewBox="0 0 140 140" className="block">
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="140" y2="140">
            <stop offset="0%" stopColor={color} stopOpacity="1" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.85" />
          </linearGradient>
        </defs>

        <circle
          cx="70"
          cy="70"
          r={r}
          fill="none"
          stroke="hsl(var(--border))"
          strokeWidth="12"
          opacity="0.6"
        />
        <circle
          cx="70"
          cy="70"
          r={r}
          fill="none"
          stroke="url(#ringGrad)"
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${c - dash}`}
          transform="rotate(-90 70 70)"
        />
      </svg>

      <div className="absolute inset-0 grid place-items-center text-center">
        <div className="leading-none">
          <div className={cn("text-4xl font-semibold tracking-tight")}>{pct}</div>
          <div className="mt-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Score</div>
        </div>
      </div>

      {caption ? (
        <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full border bg-background px-3 py-1 text-xs font-semibold text-muted-foreground shadow-sm">
          {caption}
        </div>
      ) : null}
    </div>
  );
}
