import { cn } from "@/lib/utils";

export function StatPill({
  label,
  value,
  tone = "neutral",
  "data-testid": dataTestId,
}: {
  label: string;
  value: string;
  tone?: "neutral" | "good" | "warn" | "bad";
  "data-testid"?: string;
}) {
  const toneClasses =
    tone === "good"
      ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
      : tone === "warn"
        ? "border-amber-500/25 bg-amber-500/10 text-amber-700 dark:text-amber-300"
        : tone === "bad"
          ? "border-rose-500/25 bg-rose-500/10 text-rose-700 dark:text-rose-300"
          : "border-border bg-muted/60 text-foreground/80";

  return (
    <div
      data-testid={dataTestId}
      className={cn(
        "inline-flex items-center gap-2 rounded-2xl border px-3 py-1.5 shadow-sm",
        toneClasses,
      )}
    >
      <span className="text-xs font-semibold uppercase tracking-wide opacity-80">{label}</span>
      <span className="text-sm font-bold">{value}</span>
    </div>
  );
}
