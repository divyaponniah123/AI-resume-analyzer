import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { CreateResumeRequest, UpdateResumeRequest } from "@shared/schema";
import type {
  ResumeCreateInput,
  ResumeListResponse,
  ResumeResponse,
  ResumeUpdateInput,
  ResumeAnalysisResponse,
} from "@shared/routes";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

function toSearchParams(input?: Record<string, unknown>) {
  const params = new URLSearchParams();
  if (!input) return params;
  Object.entries(input).forEach(([k, v]) => {
    if (v === undefined || v === null) return;
    const s = String(v).trim();
    if (!s) return;
    params.set(k, s);
  });
  return params;
}

export function useResumes(input?: z.infer<NonNullable<(typeof api.resumes.list)["input"]>>) {
  return useQuery({
    queryKey: [api.resumes.list.path, input?.search ?? ""],
    queryFn: async () => {
      const qs = toSearchParams(input);
      const url = qs.toString() ? `${api.resumes.list.path}?${qs.toString()}` : api.resumes.list.path;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch resumes");
      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.list.responses[200], json, "resumes.list");
      return parsed as ResumeListResponse;
    },
  });
}

export function useResume(id: number) {
  return useQuery({
    queryKey: [api.resumes.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.resumes.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch resume");
      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.get.responses[200], json, "resumes.get");
      return parsed as ResumeResponse;
    },
    enabled: Number.isFinite(id),
  });
}

export function useLatestResumeAnalysis(id: number) {
  return useQuery({
    queryKey: [api.resumes.latestAnalysis.path, id],
    queryFn: async () => {
      const url = buildUrl(api.resumes.latestAnalysis.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch latest analysis");
      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.latestAnalysis.responses[200], json, "resumes.latestAnalysis");
      return parsed;
    },
    enabled: Number.isFinite(id),
  });
}

export function useCreateResume() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateResumeRequest) => {
      const validated = parseWithLogging(api.resumes.create.input, data as ResumeCreateInput, "resumes.create.input");
      const res = await fetch(api.resumes.create.path, {
        method: api.resumes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.create.responses[400], errJson, "resumes.create.400");
          throw new Error(err.message);
        }
        throw new Error("Failed to create resume");
      }

      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.create.responses[201], json, "resumes.create.201");
      return parsed as ResumeResponse;
    },
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: [api.resumes.list.path] });
    },
  });
}

export function useUpdateResume() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: UpdateResumeRequest }) => {
      const validated = parseWithLogging(
        api.resumes.update.input,
        updates as ResumeUpdateInput,
        "resumes.update.input",
      );
      const url = buildUrl(api.resumes.update.path, { id });
      const res = await fetch(url, {
        method: api.resumes.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.update.responses[400], errJson, "resumes.update.400");
          throw new Error(err.message);
        }
        if (res.status === 404) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.update.responses[404], errJson, "resumes.update.404");
          throw new Error(err.message);
        }
        throw new Error("Failed to update resume");
      }

      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.update.responses[200], json, "resumes.update.200");
      return parsed as ResumeResponse;
    },
    onSuccess: async (_data, vars) => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: [api.resumes.list.path] }),
        qc.invalidateQueries({ queryKey: [api.resumes.get.path, vars.id] }),
      ]);
    },
  });
}

export function useDeleteResume() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.resumes.delete.path, { id });
      const res = await fetch(url, {
        method: api.resumes.delete.method,
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 404) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.delete.responses[404], errJson, "resumes.delete.404");
          throw new Error(err.message);
        }
        throw new Error("Failed to delete resume");
      }

      // 204 no content
      return;
    },
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: [api.resumes.list.path] });
    },
  });
}

export function useAnalyzeResume() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      input,
    }: {
      id: number;
      input?: z.infer<NonNullable<(typeof api.resumes.analyze)["input"]>>;
    }) => {
      const validated = input
        ? parseWithLogging(api.resumes.analyze.input, input, "resumes.analyze.input")
        : undefined;

      const url = buildUrl(api.resumes.analyze.path, { id });
      const res = await fetch(url, {
        method: api.resumes.analyze.method,
        headers: { "Content-Type": "application/json" },
        body: validated ? JSON.stringify(validated) : JSON.stringify({}),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.analyze.responses[400], errJson, "resumes.analyze.400");
          throw new Error(err.message);
        }
        if (res.status === 404) {
          const errJson = await res.json();
          const err = parseWithLogging(api.resumes.analyze.responses[404], errJson, "resumes.analyze.404");
          throw new Error(err.message);
        }
        throw new Error("Failed to analyze resume");
      }

      const json = await res.json();
      const parsed = parseWithLogging(api.resumes.analyze.responses[201], json, "resumes.analyze.201");
      return parsed as ResumeAnalysisResponse;
    },
    onSuccess: async (_data, vars) => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: [api.resumes.list.path] }),
        qc.invalidateQueries({ queryKey: [api.resumes.get.path, vars.id] }),
        qc.invalidateQueries({ queryKey: [api.resumes.latestAnalysis.path, vars.id] }),
      ]);
    },
  });
}
