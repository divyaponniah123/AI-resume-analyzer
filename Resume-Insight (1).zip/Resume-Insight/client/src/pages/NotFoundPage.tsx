import { Link } from "wouter";
import Seo from "@/components/Seo";
import AppShell from "@/components/AppShell";
import { ArrowLeft, FileX2 } from "lucide-react";

export default function NotFoundPage() {
  return (
    <>
      <Seo title="404 • Prism Resume Analyzer" description="Page not found." />
      <AppShell>
        <div className="mx-auto max-w-2xl">
          <div className="rounded-3xl border bg-card/70 p-10 text-center shadow-premium">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-muted text-muted-foreground shadow-sm">
              <FileX2 className="h-6 w-6" />
            </div>
            <h1 className="mt-6 text-3xl">Page not found</h1>
            <p className="mt-2 text-sm text-muted-foreground text-balance">
              The page you’re looking for doesn’t exist (or was moved).
            </p>
            <div className="mt-6">
              <Link
                href="/"
                data-testid="link-404-home"
                className="inline-flex items-center justify-center rounded-2xl bg-foreground px-5 py-2.5 text-sm font-semibold text-background shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg ring-focus"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Resumes
              </Link>
            </div>
          </div>
        </div>
      </AppShell>
    </>
  );
}
