import { useMemo, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import {
  ArrowLeft,
  Sparkles,
  Wand2,
  Pencil,
  Trash2,
  Copy,
  ClipboardList,
  ShieldAlert,
  KeyRound,
  BarChart3,
} from "lucide-react";
import Seo from "@/components/Seo";
import AppShell from "@/components/AppShell";
import { ResumeFormDialog } from "@/components/ResumeFormDialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { ScoreRing } from "@/components/ScoreRing";
import { CopyButton } from "@/components/CopyButton";
import { StatPill } from "@/components/StatPill";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  useAnalyzeResume,
  useDeleteResume,
  useLatestResumeAnalysis,
  useResume,
  useUpdateResume,
} from "@/hooks/use-resumes";
import type { ResumeAnalysisResponse } from "@shared/routes";
import type { Resume, UpdateResumeRequest } from "@shared/schema";
import { cn } from "@/lib/utils";

function numId(routeParam: string | undefined) {
  const n = Number(routeParam);
  return Number.isFinite(n) ? n : NaN;
}

function toneForScore(score: number): "good" | "warn" | "bad" {
  if (score >= 85) return "good";
  if (score >= 70) return "warn";
  return "bad";
}

function ListBlock({
  title,
  items,
  icon,
  empty,
  testId,
  tone = "neutral",
}: {
  title: string;
  items: string[];
  icon: React.ReactNode;
  empty: string;
  testId: string;
  tone?: "neutral" | "good" | "warn" | "bad";
}) {
  const toneCls =
    tone === "good"
      ? "border-emerald-500/20 bg-emerald-500/8"
      : tone === "warn"
        ? "border-amber-500/20 bg-amber-500/8"
        : tone === "bad"
          ? "border-rose-500/20 bg-rose-500/8"
          : "border-border bg-card/60";

  return (
    <Card className={cn("rounded-3xl border p-6 shadow-premium", toneCls)} data-testid={testId}>
      <div className="flex items-center gap-2">
        <div className="grid h-9 w-9 place-items-center rounded-2xl border bg-background/40 shadow-sm">
          {icon}
        </div>
        <div className="text-lg">{title}</div>
      </div>
      <div className="mt-4">
        {items.length === 0 ? (
          <div className="text-sm text-muted-foreground" data-testid={`${testId}-empty`}>
            {empty}
          </div>
        ) : (
          <ul className="space-y-2" data-testid={`${testId}-list`}>
            {items.map((s, i) => (
              <li key={i} className="flex gap-2 text-sm leading-relaxed">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-foreground/60" />
                <span className="text-foreground/85">{s}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  );
}

export default function ResumeDetailPage() {
  const { toast } = useToast();
  const [, setLoc] = useLocation();
  const [, params] = useRoute<{ id: string }>("/resumes/:id");
  const id = numId(params?.id);

  const resumeQ = useResume(id);
  const analysisQ = useLatestResumeAnalysis(id);

  const analyze = useAnalyzeResume();
  const update = useUpdateResume();
  const del = useDeleteResume();

  const resume = resumeQ.data ?? null;
  const analysis = (analysisQ.data as ResumeAnalysisResponse | null) ?? null;

  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const [analyzeJobTitle, setAnalyzeJobTitle] = useState("");
  const [analyzeJobDescription, setAnalyzeJobDescription] = useState("");

  const effectiveJobTitle = useMemo(() => {
    return analyzeJobTitle.trim() || resume?.jobTitle?.trim() || "";
  }, [analyzeJobTitle, resume?.jobTitle]);

  const effectiveJobDescription = useMemo(() => {
    return analyzeJobDescription.trim() || resume?.jobDescription?.trim() || "";
  }, [analyzeJobDescription, resume?.jobDescription]);

  const pageTitle = resume ? `${resume.title} • Prism Resume Analyzer` : "Resume • Prism Resume Analyzer";

  return (
    <>
      <Seo
        title={pageTitle}
        description="View resume content, run AI analysis, inspect ATS keywords, and track improvements over time."
      />
      <AppShell>
        <div className="flex flex-col gap-6 md:gap-8">
          <section className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div className="flex items-start gap-3">
              <Button
                data-testid="btn-back-to-list"
                variant="secondary"
                onClick={() => setLoc("/")}
                className="rounded-2xl shadow-sm"
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="ml-2 hidden sm:inline">Resumes</span>
              </Button>

              <div>
                <h1 data-testid="resume-detail-title" className="text-3xl md:text-4xl text-balance">
                  {resumeQ.isLoading ? "Loading…" : resume ? resume.title : "Resume not found"}
                </h1>
                <p data-testid="resume-detail-subtitle" className="mt-2 text-sm md:text-base text-muted-foreground text-balance">
                  {resume
                    ? "Review and analyze. Small iterations add up quickly."
                    : resumeQ.isError
                      ? (resumeQ.error as Error)?.message
                      : "If you deleted it, return to the list."}
                </p>

                {resume ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <StatPill
                      data-testid="pill-target"
                      label="Target"
                      value={resume.jobTitle?.trim() ? resume.jobTitle : "Not set"}
                      tone={resume.jobTitle?.trim() ? "good" : "neutral"}
                    />
                    <StatPill
                      data-testid="pill-jd"
                      label="Job desc"
                      value={resume.jobDescription?.trim() ? "Attached" : "None"}
                      tone={resume.jobDescription?.trim() ? "good" : "warn"}
                    />
                  </div>
                ) : null}
              </div>
            </div>

            {resume ? (
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <Button
                  data-testid="btn-edit"
                  variant="secondary"
                  onClick={() => setEditOpen(true)}
                  className="rounded-2xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium"
                >
                  <Pencil className="h-4 w-4" />
                  <span className="ml-2">Edit</span>
                </Button>

                <Button
                  data-testid="btn-delete"
                  variant="secondary"
                  onClick={() => setDeleteOpen(true)}
                  className="rounded-2xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium"
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                  <span className="ml-2">Delete</span>
                </Button>
              </div>
            ) : null}
          </section>

          {resume ? (
            <section className="grid grid-cols-1 gap-5 lg:grid-cols-12">
              <div className="lg:col-span-5">
                <div className="space-y-5">
                  <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <div className="grid h-9 w-9 place-items-center rounded-2xl bg-primary/10 text-primary shadow-sm">
                          <Sparkles className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="text-lg">Latest analysis</div>
                          <div className="text-xs text-muted-foreground">
                            {analysis ? "Generated" : "Not yet generated"}
                          </div>
                        </div>
                      </div>

                      {analysis ? (
                        <Badge
                          data-testid="badge-score-tone"
                          className={cn(
                            "rounded-full",
                            toneForScore(analysis.overallScore) === "good"
                              ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                              : toneForScore(analysis.overallScore) === "warn"
                                ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                                : "bg-rose-500/15 text-rose-700 dark:text-rose-300",
                          )}
                        >
                          {toneForScore(analysis.overallScore) === "good"
                            ? "Strong"
                            : toneForScore(analysis.overallScore) === "warn"
                              ? "Promising"
                              : "Needs work"}
                        </Badge>
                      ) : (
                        <Badge data-testid="badge-no-analysis" variant="secondary" className="rounded-full">
                          None
                        </Badge>
                      )}
                    </div>

                    <div className="mt-6 flex items-center justify-center">
                      <ScoreRing
                        data-testid="score-ring"
                        score={analysis?.overallScore ?? 0}
                        caption={analysis ? "Overall" : "Run analysis"}
                      />
                    </div>

                    <div className="mt-6 rounded-3xl border bg-background/50 p-4">
                      <div className="text-sm font-semibold">Run a new analysis</div>
                      <div className="mt-1 text-xs text-muted-foreground text-balance">
                        You can override the target job title/description for this run without editing the resume.
                      </div>

                      <div className="mt-4 space-y-3">
                        <Textarea
                          data-testid="input-analyze-jobTitle"
                          value={analyzeJobTitle}
                          onChange={(e) => setAnalyzeJobTitle(e.target.value)}
                          placeholder="Optional: Job title override (e.g., Data Analyst)"
                          className="min-h-[52px] rounded-2xl border-2 bg-card/60 focus-visible:ring-4 focus-visible:ring-ring/15"
                        />
                        <Textarea
                          data-testid="input-analyze-jobDescription"
                          value={analyzeJobDescription}
                          onChange={(e) => setAnalyzeJobDescription(e.target.value)}
                          placeholder="Optional: Job description override…"
                          className="min-h-[110px] rounded-2xl border-2 bg-card/60 focus-visible:ring-4 focus-visible:ring-ring/15"
                        />

                        <Button
                          data-testid="btn-analyze"
                          disabled={analyze.isPending}
                          onClick={() => {
                            analyze.mutate(
                              {
                                id: resume.id,
                                input: {
                                  jobTitle: effectiveJobTitle || undefined,
                                  jobDescription: effectiveJobDescription || undefined,
                                },
                              },
                              {
                                onSuccess: () => {
                                  toast({
                                    title: "Analysis complete",
                                    description: "Scroll for strengths, gaps, ATS keywords, and section scores.",
                                  });
                                },
                                onError: (e) => {
                                  toast({
                                    title: "Analysis failed",
                                    description: (e as Error).message,
                                    variant: "destructive",
                                  });
                                },
                              },
                            );
                          }}
                          className="w-full rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg transition-all duration-300"
                        >
                          <Wand2 className="h-4 w-4" />
                          <span className="ml-2">{analyze.isPending ? "Analyzing…" : "Analyze resume"}</span>
                        </Button>
                      </div>
                    </div>
                  </Card>

                  <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <div className="grid h-9 w-9 place-items-center rounded-2xl border bg-background/40 shadow-sm">
                          <ClipboardList className="h-4 w-4" />
                        </div>
                        <div className="text-lg">Resume content</div>
                      </div>

                      <Button
                        data-testid="btn-copy-resumeText"
                        variant="secondary"
                        onClick={async () => {
                          try {
                            await navigator.clipboard.writeText(resume.resumeText);
                            toast({ title: "Copied", description: "Resume text copied to clipboard." });
                          } catch (e) {
                            toast({
                              title: "Copy failed",
                              description: e instanceof Error ? e.message : "Clipboard unavailable",
                              variant: "destructive",
                            });
                          }
                        }}
                        className="rounded-xl shadow-sm"
                      >
                        <Copy className="h-4 w-4" />
                        <span className="ml-2">Copy</span>
                      </Button>
                    </div>

                    <div className="mt-4 max-h-[420px] overflow-auto rounded-2xl border bg-background/50 p-4">
                      <pre
                        data-testid="resume-text"
                        className="whitespace-pre-wrap break-words text-sm leading-relaxed text-foreground/85"
                      >
                        {resume.resumeText}
                      </pre>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Badge data-testid="badge-resume-length" variant="secondary" className="rounded-full">
                        {(resume.resumeText?.length ?? 0).toLocaleString()} chars
                      </Badge>
                      <Badge data-testid="badge-has-jobTitle" variant="secondary" className="rounded-full">
                        jobTitle: {resume.jobTitle?.trim() ? "yes" : "no"}
                      </Badge>
                      <Badge data-testid="badge-has-jobDescription" variant="secondary" className="rounded-full">
                        jobDescription: {resume.jobDescription?.trim() ? "yes" : "no"}
                      </Badge>
                    </div>
                  </Card>
                </div>
              </div>

              <div className="lg:col-span-7">
                <Tabs defaultValue="summary" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 rounded-2xl bg-card/70 p-1 shadow-sm md:grid-cols-4">
                    <TabsTrigger data-testid="tab-summary" value="summary" className="rounded-xl">
                      Summary
                    </TabsTrigger>
                    <TabsTrigger data-testid="tab-breakdown" value="breakdown" className="rounded-xl">
                      Breakdown
                    </TabsTrigger>
                    <TabsTrigger data-testid="tab-ats" value="ats" className="rounded-xl">
                      ATS
                    </TabsTrigger>
                    <TabsTrigger data-testid="tab-risk" value="risk" className="rounded-xl">
                      Risk
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="summary" className="mt-5 space-y-5">
                    <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <div className="grid h-9 w-9 place-items-center rounded-2xl bg-primary/10 text-primary shadow-sm">
                              <Sparkles className="h-5 w-5" />
                            </div>
                            <div>
                              <div className="text-lg">Summary</div>
                              <div className="text-xs text-muted-foreground">A tight executive overview.</div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 sm:flex-row">
                          <CopyButton
                            testId="btn-copy-summary"
                            text={analysis?.summary ?? ""}
                            label="Copy summary"
                          />
                          <CopyButton
                            testId="btn-copy-improvements"
                            text={(analysis?.improvements ?? []).join("\n")}
                            label="Copy improvements"
                          />
                        </div>
                      </div>

                      <div className="mt-4 rounded-2xl border bg-background/50 p-4">
                        {analysis ? (
                          <p data-testid="analysis-summary" className="text-sm leading-relaxed text-foreground/85">
                            {analysis.summary}
                          </p>
                        ) : (
                          <p data-testid="analysis-summary-empty" className="text-sm text-muted-foreground">
                            Run analysis to generate a summary.
                          </p>
                        )}
                      </div>
                    </Card>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                      <ListBlock
                        testId="block-strengths"
                        title="Strengths"
                        icon={<BarChart3 className="h-4 w-4 text-emerald-600 dark:text-emerald-300" />}
                        items={analysis?.strengths ?? []}
                        empty="No strengths yet—run analysis."
                        tone="good"
                      />
                      <ListBlock
                        testId="block-improvements"
                        title="Improvements"
                        icon={<Wand2 className="h-4 w-4 text-primary" />}
                        items={analysis?.improvements ?? []}
                        empty="No suggestions yet—run analysis."
                        tone="warn"
                      />
                      <ListBlock
                        testId="block-gaps"
                        title="Gaps"
                        icon={<ShieldAlert className="h-4 w-4 text-amber-700 dark:text-amber-300" />}
                        items={analysis?.gaps ?? []}
                        empty="No gaps found (or no analysis yet)."
                        tone="warn"
                      />
                      <ListBlock
                        testId="block-redflags"
                        title="Red flags"
                        icon={<ShieldAlert className="h-4 w-4 text-rose-600 dark:text-rose-300" />}
                        items={analysis?.redFlags ?? []}
                        empty="No red flags detected."
                        tone="bad"
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="breakdown" className="mt-5 space-y-5">
                    <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <div className="grid h-9 w-9 place-items-center rounded-2xl border bg-background/40 shadow-sm">
                            <BarChart3 className="h-4 w-4" />
                          </div>
                          <div>
                            <div className="text-lg">Section scores</div>
                            <div className="text-xs text-muted-foreground">Quick signal by resume section.</div>
                          </div>
                        </div>
                        <Badge data-testid="badge-sections-count" variant="secondary" className="rounded-full">
                          {analysis ? Object.keys(analysis.sectionsScore ?? {}).length : 0} sections
                        </Badge>
                      </div>

                      <div className="mt-4 rounded-2xl border bg-background/50 p-2">
                        {!analysis ? (
                          <div className="p-4 text-sm text-muted-foreground" data-testid="sections-empty">
                            No analysis yet. Run analysis to get section-level scoring.
                          </div>
                        ) : (
                          <Table data-testid="sections-table">
                            <TableHeader>
                              <TableRow>
                                <TableHead>Section</TableHead>
                                <TableHead className="text-right">Score</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {Object.entries(analysis.sectionsScore ?? {})
                                .sort((a, b) => b[1] - a[1])
                                .map(([k, v]) => (
                                  <TableRow key={k}>
                                    <TableCell className="font-medium">{k}</TableCell>
                                    <TableCell className="text-right">
                                      <span
                                        className={cn(
                                          "inline-flex min-w-[54px] justify-end rounded-full px-2 py-1 text-xs font-semibold",
                                          v >= 85
                                            ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                                            : v >= 70
                                              ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                                              : "bg-rose-500/15 text-rose-700 dark:text-rose-300",
                                        )}
                                      >
                                        {v}
                                      </span>
                                    </TableCell>
                                  </TableRow>
                                ))}
                            </TableBody>
                          </Table>
                        )}
                      </div>
                    </Card>
                  </TabsContent>

                  <TabsContent value="ats" className="mt-5 space-y-5">
                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                      <ListBlock
                        testId="block-atsKeywords"
                        title="ATS keywords"
                        icon={<KeyRound className="h-4 w-4 text-primary" />}
                        items={analysis?.atsKeywords ?? []}
                        empty="No keywords yet—run analysis."
                        tone="good"
                      />
                      <ListBlock
                        testId="block-missingKeywords"
                        title="Missing keywords"
                        icon={<KeyRound className="h-4 w-4 text-amber-700 dark:text-amber-300" />}
                        items={analysis?.missingKeywords ?? []}
                        empty="No missing keywords detected."
                        tone="warn"
                      />
                    </div>

                    <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                      <div className="text-lg">Target used for analysis</div>
                      <div className="mt-2 grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="rounded-2xl border bg-background/50 p-4">
                          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                            Job Title
                          </div>
                          <div data-testid="analysis-target-title" className="mt-2 text-sm font-semibold text-foreground/85">
                            {effectiveJobTitle || "—"}
                          </div>
                        </div>
                        <div className="rounded-2xl border bg-background/50 p-4">
                          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                            Job Description
                          </div>
                          <div
                            data-testid="analysis-target-description"
                            className="mt-2 text-sm leading-relaxed text-foreground/80 whitespace-pre-wrap"
                          >
                            {effectiveJobDescription || "—"}
                          </div>
                        </div>
                      </div>
                    </Card>
                  </TabsContent>

                  <TabsContent value="risk" className="mt-5 space-y-5">
                    <Card className="rounded-3xl border bg-card/70 p-6 shadow-premium">
                      <div className="flex items-center gap-2">
                        <div className="grid h-9 w-9 place-items-center rounded-2xl bg-rose-500/10 text-rose-600 shadow-sm">
                          <ShieldAlert className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="text-lg">Risk checks</div>
                          <div className="text-xs text-muted-foreground">Things that can confuse recruiters or ATS.</div>
                        </div>
                      </div>

                      <div className="mt-4">
                        <ListBlock
                          testId="block-redflags-standalone"
                          title="Red flags"
                          icon={<ShieldAlert className="h-4 w-4 text-rose-600 dark:text-rose-300" />}
                          items={analysis?.redFlags ?? []}
                          empty="No red flags detected."
                          tone="bad"
                        />
                      </div>

                      <div className="mt-5 rounded-2xl border bg-background/50 p-4 text-sm text-muted-foreground">
                        If you see red flags: fix formatting, add dates and scope, avoid vague claims, and keep bullets parallel.
                      </div>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </section>
          ) : (
            <Card className="rounded-3xl border bg-card/70 p-10 shadow-premium">
              <div className="flex flex-col items-center text-center">
                <div className="grid h-14 w-14 place-items-center rounded-3xl bg-muted text-muted-foreground shadow-sm">
                  <Sparkles className="h-6 w-6" />
                </div>
                <h2 className="mt-5 text-2xl">Nothing to show</h2>
                <p className="mt-2 max-w-xl text-sm text-muted-foreground text-balance">
                  This resume might not exist anymore. Return to the list to pick another.
                </p>
                <div className="mt-6">
                  <Link
                    href="/"
                    data-testid="link-back-home"
                    className="inline-flex items-center justify-center rounded-2xl bg-foreground px-5 py-2.5 text-sm font-semibold text-background shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg ring-focus"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Resumes
                  </Link>
                </div>
              </div>
            </Card>
          )}
        </div>

        {resume ? (
          <>
            <ResumeFormDialog
              open={editOpen}
              onOpenChange={setEditOpen}
              mode="edit"
              initial={resume as unknown as Resume}
              onCreate={() => {}}
              onUpdate={(values: UpdateResumeRequest) => {
                update.mutate(
                  { id: resume.id, updates: values },
                  {
                    onSuccess: () => {
                      toast({ title: "Saved", description: "Resume updated." });
                      setEditOpen(false);
                    },
                    onError: (e) => {
                      toast({ title: "Update failed", description: (e as Error).message, variant: "destructive" });
                    },
                  },
                );
              }}
              isPending={update.isPending}
            />

            <ConfirmDialog
              open={deleteOpen}
              onOpenChange={setDeleteOpen}
              title="Delete this resume?"
              description="This will permanently remove the resume and all analyses."
              confirmLabel="Delete"
              cancelLabel="Cancel"
              confirmTestId="confirm-delete-detail"
              cancelTestId="cancel-delete-detail"
              destructive
              isPending={del.isPending}
              onConfirm={() => {
                del.mutate(resume.id, {
                  onSuccess: () => {
                    toast({ title: "Deleted", description: "Resume removed." });
                    setDeleteOpen(false);
                    setLoc("/");
                  },
                  onError: (e) => {
                    toast({ title: "Delete failed", description: (e as Error).message, variant: "destructive" });
                  },
                });
              }}
            />
          </>
        ) : null}
      </AppShell>
    </>
  );
}
