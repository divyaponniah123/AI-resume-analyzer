import { useState } from "react";
import { useLocation } from "wouter";
import { Sparkles, ArrowLeft, Wand2 } from "lucide-react";
import Seo from "@/components/Seo";
import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { ResumeFormDialog } from "@/components/ResumeFormDialog";
import { useCreateResume } from "@/hooks/use-resumes";
import { useToast } from "@/hooks/use-toast";
import type { CreateResumeRequest } from "@shared/schema";

export default function NewResumePage() {
  const { toast } = useToast();
  const [, setLoc] = useLocation();
  const create = useCreateResume();
  const [open, setOpen] = useState(true);

  const onCreate = (values: CreateResumeRequest) => {
    create.mutate(values, {
      onSuccess: (r) => {
        toast({ title: "Resume created", description: "Opening detail page…" });
        setOpen(false);
        setLoc(`/resumes/${r.id}`);
      },
      onError: (e) => {
        toast({ title: "Create failed", description: (e as Error).message, variant: "destructive" });
      },
    });
  };

  return (
    <>
      <Seo
        title="New Resume • Prism Resume Analyzer"
        description="Create a new resume and run an AI analysis with ATS keyword matching."
      />
      <AppShell>
        <div className="relative overflow-hidden rounded-3xl border bg-card/70 p-8 shadow-premium md:p-12">
          <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/12 blur-2xl" />
          <div className="absolute -left-24 -bottom-24 h-64 w-64 rounded-full bg-accent/10 blur-2xl" />

          <div className="relative">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl text-balance">Create a resume</h1>
                <p className="mt-2 max-w-2xl text-sm md:text-base text-muted-foreground text-balance">
                  Paste your content, add a target role, then generate a focused analysis. Minimal friction, maximum signal.
                </p>

                <div className="mt-4 inline-flex items-center gap-2 rounded-2xl border bg-background/50 px-3 py-2 text-sm text-muted-foreground shadow-sm">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <span>Analysis includes: strengths • gaps • improvements • missing ATS keywords</span>
                </div>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row">
                <Button
                  data-testid="btn-back"
                  variant="secondary"
                  onClick={() => setLoc("/")}
                  className="rounded-2xl shadow-sm"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span className="ml-2">Back</span>
                </Button>

                <Button
                  data-testid="btn-open-form"
                  onClick={() => setOpen(true)}
                  className="rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg transition-all duration-300"
                >
                  <Wand2 className="h-4 w-4" />
                  <span className="ml-2">Open editor</span>
                </Button>
              </div>
            </div>
          </div>
        </div>

        <ResumeFormDialog
          open={open}
          onOpenChange={(v) => {
            setOpen(v);
            if (!v) setLoc("/");
          }}
          mode="create"
          onCreate={onCreate}
          onUpdate={() => {}}
          isPending={create.isPending}
        />
      </AppShell>
    </>
  );
}
