import { useMemo, useState } from "react";
import { Link } from "wouter";
import { Search, Plus, ArrowUpRight, FileText, Trash2, Pencil, Sparkles } from "lucide-react";
import Seo from "@/components/Seo";
import AppShell from "@/components/AppShell";
import { ResumeFormDialog } from "@/components/ResumeFormDialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { StatPill } from "@/components/StatPill";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useCreateResume, useDeleteResume, useResumes, useUpdateResume } from "@/hooks/use-resumes";
import type { Resume } from "@shared/schema";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

function formatCreatedAt(createdAt: unknown) {
  const d = createdAt instanceof Date ? createdAt : new Date(String(createdAt));
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

export default function ResumesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");

  const q = useResumes({ search: search.trim() ? search.trim() : undefined });
  const items = q.data ?? [];

  const [createOpen, setCreateOpen] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<Resume | null>(null);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState<Resume | null>(null);

  const create = useCreateResume();
  const update = useUpdateResume();
  const del = useDeleteResume();

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return items;
    return items.filter((r) => (r.title ?? "").toLowerCase().includes(s));
  }, [items, search]);

  return (
    <>
      <Seo title="Resumes • Prism Resume Analyzer" description="Create resumes, target a job, and generate AI-powered analysis with ATS keyword insights." />
      <AppShell>
        <div className="flex flex-col gap-6 md:gap-8">
          <section className="rounded-3xl border bg-card/70 p-6 shadow-premium md:p-8">
            <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl text-balance">Resumes</h1>
                <p className="mt-2 max-w-2xl text-sm md:text-base text-muted-foreground text-balance">
                  Keep multiple versions. Analyze against a target role. Ship the strongest narrative—fast.
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  <StatPill data-testid="stat-total" label="Total" value={String(items.length)} />
                  <StatPill
                    data-testid="stat-tip"
                    label="Tip"
                    value="Add job description for ATS"
                    tone="neutral"
                  />
                </div>
              </div>

              <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
                <div className="relative w-full md:w-[340px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    data-testid="input-search"
                    type="search"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by title…"
                    className="h-11 rounded-2xl border-2 bg-background/60 pl-10 shadow-sm focus-visible:ring-4 focus-visible:ring-ring/15"
                  />
                </div>

                <Button
                  data-testid="btn-open-create"
                  onClick={() => setCreateOpen(true)}
                  className="h-11 rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg transition-all duration-300"
                >
                  <Plus className="h-4 w-4" />
                  <span className="ml-2">Create</span>
                </Button>
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {q.isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  data-testid={`skeleton-card-${i}`}
                  className="h-[170px] rounded-3xl border bg-card/60 shadow-sm animate-pulse"
                />
              ))
            ) : q.isError ? (
              <Card className="col-span-full rounded-3xl border bg-card/70 p-8 shadow-premium">
                <div className="flex items-start gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl bg-destructive/10 text-destructive">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <div data-testid="error-title" className="text-lg font-semibold">
                      Couldn’t load resumes
                    </div>
                    <div data-testid="error-message" className="mt-1 text-sm text-muted-foreground">
                      {(q.error as Error)?.message ?? "Unexpected error"}
                    </div>
                    <div className="mt-4">
                      <Button data-testid="btn-retry" variant="secondary" onClick={() => q.refetch()} className="rounded-xl">
                        Retry
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ) : filtered.length === 0 ? (
              <Card className="col-span-full rounded-3xl border bg-card/70 p-10 shadow-premium">
                <div className="mx-auto flex max-w-xl flex-col items-center text-center">
                  <div className="grid h-14 w-14 place-items-center rounded-3xl bg-primary/10 text-primary shadow-sm">
                    <FileText className="h-6 w-6" />
                  </div>
                  <h2 className="mt-5 text-2xl">No resumes yet</h2>
                  <p className="mt-2 text-sm text-muted-foreground text-balance">
                    Create your first resume, paste the content, then run analysis to get a score, strengths, gaps, and ATS keywords.
                  </p>
                  <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                    <Button
                      data-testid="btn-empty-create"
                      onClick={() => setCreateOpen(true)}
                      className="rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg transition-all duration-300"
                    >
                      <Plus className="h-4 w-4" />
                      <span className="ml-2">Create resume</span>
                    </Button>
                    <Link
                      href="/resumes/new"
                      data-testid="link-empty-newpage"
                      className="inline-flex items-center justify-center rounded-2xl border bg-card px-4 py-2 text-sm font-semibold text-foreground/80 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium hover:text-foreground ring-focus"
                    >
                      Open full editor
                      <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </Card>
            ) : (
              filtered.map((r) => (
                <Card
                  key={r.id}
                  data-testid={`resume-card-${r.id}`}
                  className={cn(
                    "group relative overflow-hidden rounded-3xl border bg-card/70 p-6 shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg",
                  )}
                >
                  <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 data-testid={`resume-title-${r.id}`} className="text-xl text-balance">
                          {r.title}
                        </h3>
                        <Badge
                          data-testid={`resume-badge-${r.id}`}
                          variant="secondary"
                          className="rounded-full"
                        >
                          {formatCreatedAt(r.createdAt)}
                        </Badge>
                      </div>

                      <div className="mt-2 text-sm text-muted-foreground">
                        {r.jobTitle?.trim() ? (
                          <span data-testid={`resume-jobTitle-${r.id}`} className="inline-flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary/80" />
                            Target: <span className="font-semibold text-foreground/80">{r.jobTitle}</span>
                          </span>
                        ) : (
                          <span data-testid={`resume-jobTitle-${r.id}`}>No target role yet</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        data-testid={`btn-edit-${r.id}`}
                        variant="secondary"
                        size="icon"
                        onClick={() => {
                          setEditing(r as Resume);
                          setEditOpen(true);
                        }}
                        className="rounded-2xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>

                      <Button
                        data-testid={`btn-delete-${r.id}`}
                        variant="secondary"
                        size="icon"
                        onClick={() => {
                          setDeleting(r as Resume);
                          setDeleteOpen(true);
                        }}
                        className="rounded-2xl shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>

                  <div className="mt-5 flex items-center justify-between">
                    <div className="flex flex-wrap gap-2">
                      <Badge className="rounded-full bg-primary/10 text-primary hover:bg-primary/15" data-testid={`badge-textlen-${r.id}`}>
                        {(r.resumeText?.length ?? 0).toLocaleString()} chars
                      </Badge>
                      {r.jobDescription?.trim() ? (
                        <Badge className="rounded-full bg-accent/10 text-accent-foreground" data-testid={`badge-hasjd-${r.id}`}>
                          JD attached
                        </Badge>
                      ) : (
                        <Badge className="rounded-full bg-muted/60 text-muted-foreground" data-testid={`badge-hasjd-${r.id}`}>
                          No JD
                        </Badge>
                      )}
                    </div>

                    <Link
                      href={`/resumes/${r.id}`}
                      data-testid={`link-open-${r.id}`}
                      className="inline-flex items-center gap-2 rounded-2xl bg-foreground px-4 py-2 text-sm font-semibold text-background shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg ring-focus"
                    >
                      Open
                      <ArrowUpRight className="h-4 w-4" />
                    </Link>
                  </div>
                </Card>
              ))
            )}
          </section>
        </div>

        <ResumeFormDialog
          open={createOpen}
          onOpenChange={setCreateOpen}
          mode="create"
          onCreate={(values) => {
            create.mutate(values, {
              onSuccess: () => {
                setCreateOpen(false);
                toast({ title: "Resume created", description: "Ready for analysis." });
              },
              onError: (e) => {
                toast({ title: "Create failed", description: (e as Error).message, variant: "destructive" });
              },
            });
          }}
          onUpdate={() => {}}
          isPending={create.isPending}
        />

        <ResumeFormDialog
          open={editOpen}
          onOpenChange={setEditOpen}
          mode="edit"
          initial={editing}
          onCreate={() => {}}
          onUpdate={(values) => {
            if (!editing) return;
            update.mutate(
              { id: editing.id, updates: values },
              {
                onSuccess: () => {
                  setEditOpen(false);
                  toast({ title: "Saved", description: "Resume updated." });
                },
                onError: (e) => {
                  toast({ title: "Update failed", description: (e as Error).message, variant: "destructive" });
                },
              },
            );
          }}
          isPending={update.isPending}
        />

        <ConfirmDialog
          open={deleteOpen}
          onOpenChange={setDeleteOpen}
          title="Delete this resume?"
          description="This will permanently remove the resume and all analyses associated with it."
          confirmLabel="Delete"
          cancelLabel="Cancel"
          confirmTestId="confirm-delete"
          cancelTestId="cancel-delete"
          destructive
          isPending={del.isPending}
          onConfirm={() => {
            if (!deleting) return;
            del.mutate(deleting.id, {
              onSuccess: () => {
                setDeleteOpen(false);
                toast({ title: "Deleted", description: "Resume removed." });
              },
              onError: (e) => {
                toast({ title: "Delete failed", description: (e as Error).message, variant: "destructive" });
              },
            });
          }}
        />
      </AppShell>
    </>
  );
}
