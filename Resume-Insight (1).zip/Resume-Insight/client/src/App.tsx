import { useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import ResumesPage from "@/pages/ResumesPage";
import NewResumePage from "@/pages/NewResumePage";
import ResumeDetailPage from "@/pages/ResumeDetailPage";
import NotFoundPage from "@/pages/NotFoundPage";
import { initTheme } from "@/components/AppShell";

function Router() {
  return (
    <Switch>
      <Route path="/" component={ResumesPage} />
      <Route path="/resumes/new" component={NewResumePage} />
      <Route path="/resumes/:id" component={ResumeDetailPage} />
      <Route component={NotFoundPage} />
    </Switch>
  );
}

function App() {
  useEffect(() => {
    initTheme();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
