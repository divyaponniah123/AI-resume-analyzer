## Packages
(none needed)

## Notes
Uses existing shadcn/ui components already present in repo (dialog, form, input, textarea, card, badge, table, tabs, toast, tooltip)
Frontend uses @shared/routes for api paths + zod schemas and parses with safeParse() logging
No stock images used
