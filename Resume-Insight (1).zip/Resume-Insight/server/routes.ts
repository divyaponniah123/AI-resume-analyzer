import type { Express } from "express";
import type { Server } from "http";
import { z } from "zod";
import OpenAI from "openai";
import { api } from "@shared/routes";
import { storage } from "./storage";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

function zodErrorTo400(err: z.ZodError) {
  return {
    message: err.errors[0]?.message ?? "Invalid request",
    field: err.errors[0]?.path?.join(".") || undefined,
  };
}

async function analyzeResumeWithAI(input: {
  resumeText: string;
  jobTitle?: string;
  jobDescription?: string;
}): Promise<{
  overallScore: number;
  summary: string;
  strengths: string[];
  gaps: string[];
  improvements: string[];
  atsKeywords: string[];
  missingKeywords: string[];
  redFlags: string[];
  sectionsScore: Record<string, number>;
}> {
  const jobContext =
    (input.jobTitle && input.jobTitle.trim()) ||
    (input.jobDescription && input.jobDescription.trim())
      ? {
          jobTitle: input.jobTitle?.trim() || "",
          jobDescription: input.jobDescription?.trim() || "",
        }
      : null;

  const system =
    "You are an expert recruiter and ATS specialist. Analyze resumes and provide actionable feedback. " +
    "Return STRICT JSON matching the schema: " +
    "{overallScore:0-100, summary:string, strengths:string[], gaps:string[], improvements:string[], atsKeywords:string[], missingKeywords:string[], redFlags:string[], sectionsScore: Record<string, number>}. " +
    "Keep arrays concise (3-8 items). Use plain text, no markdown.";

  const userPayload = {
    resumeText: input.resumeText,
    job: jobContext,
  };

  const resp = await openai.chat.completions.create({
    model: "gpt-5.2",
    messages: [
      { role: "system", content: system },
      {
        role: "user",
        content:
          "Analyze this resume for a specific job if provided. Respond with JSON only.\n\n" +
          JSON.stringify(userPayload),
      },
    ],
    response_format: { type: "json_object" },
    max_completion_tokens: 1200,
  });

  const content = resp.choices[0]?.message?.content || "{}";
  const parsed = JSON.parse(content);

  const safe = api.resumes.analyze.responses[201].omit({
    id: true,
    resumeId: true,
    createdAt: true,
  });

  return safe.parse(parsed);
}

async function seedDatabase(): Promise<void> {
  const existing = await storage.listResumes();
  if (existing.length > 0) return;

  await storage.createResume({
    title: "Software Engineer - Full Stack",
    resumeText:
      "Alex Morgan\n\nSUMMARY\nFull-stack engineer with 5+ years building web apps in TypeScript, React, and Node.js. Experience with Postgres, CI/CD, and cloud deployments.\n\nEXPERIENCE\nSenior Software Engineer, Northwind Labs (2022-Present)\n- Built internal analytics dashboard in React + TanStack Query, reducing report time by 40%.\n- Designed REST APIs in Express/TypeScript and improved p95 latency from 900ms to 220ms.\n- Led migration from ad-hoc SQL to Drizzle ORM with schema validation.\n\nSoftware Engineer, Contoso (2020-2022)\n- Implemented feature flags and A/B tests, increasing activation by 8%.\n- Owned payments workflow and webhook processing, improving reliability.\n\nSKILLS\nTypeScript, React, Node.js, Express, Postgres, Docker, AWS, GitHub Actions\n\nEDUCATION\nB.S. Computer Science",
    jobTitle: "Full Stack Engineer",
    jobDescription:
      "We need a full stack engineer with strong TypeScript, React, Node.js, and Postgres. Bonus for testing, performance, and system design.",
  });

  await storage.createResume({
    title: "Data Analyst",
    resumeText:
      "Jordan Lee\n\nSUMMARY\nData analyst with 3 years experience in SQL, dashboards, and stakeholder reporting.\n\nEXPERIENCE\nData Analyst, RetailCo (2023-Present)\n- Built monthly KPI dashboards and automated reporting workflows.\n- Wrote SQL queries for customer cohort analysis and retention.\n\nSKILLS\nSQL, Excel, Tableau, Python, Statistics\n\nEDUCATION\nB.A. Economics",
    jobTitle: "Data Analyst",
    jobDescription:
      "Looking for strong SQL, dashboarding, and communication skills. Experience with cohort analysis and experiment measurement preferred.",
  });

  await storage.createResume({
    title: "Product Manager",
    resumeText:
      "Sam Patel\n\nSUMMARY\nProduct manager with experience launching B2B SaaS features end-to-end. Strong at discovery, prioritization, and cross-functional execution.\n\nEXPERIENCE\nProduct Manager, CloudSuite (2021-Present)\n- Led roadmap for onboarding improvements; improved trial-to-paid by 12%.\n- Partnered with design and engineering to ship billing portal and support tooling.\n\nSKILLS\nProduct discovery, PRDs, Analytics, Stakeholder management\n\nEDUCATION\nM.B.A.",
    jobTitle: "Product Manager",
    jobDescription:
      "Seeking a PM with strong communication, experimentation mindset, and ability to work with engineering and design to ship impactful improvements.",
  });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  await seedDatabase();

  app.get(api.resumes.list.path, async (req, res) => {
    const parsed = api.resumes.list.input?.safeParse(req.query);
    const search = parsed?.success ? parsed.data?.search : undefined;
    const list = await storage.listResumes(search);
    res.json(list);
  });

  app.get(api.resumes.get.path, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const resume = await storage.getResume(id);
    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    res.json(resume);
  });

  app.post(api.resumes.create.path, async (req, res) => {
    try {
      const input = api.resumes.create.input.parse(req.body);
      const created = await storage.createResume(input);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorTo400(err));
      }
      throw err;
    }
  });

  app.patch(api.resumes.update.path, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(404).json({ message: "Resume not found" });
    }

    try {
      const updates = api.resumes.update.input.parse(req.body);
      const updated = await storage.updateResume(id, updates);
      if (!updated) {
        return res.status(404).json({ message: "Resume not found" });
      }
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorTo400(err));
      }
      throw err;
    }
  });

  app.delete(api.resumes.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const ok = await storage.deleteResume(id);
    if (!ok) {
      return res.status(404).json({ message: "Resume not found" });
    }

    res.status(204).send();
  });

  app.get(api.resumes.latestAnalysis.path, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const resume = await storage.getResume(id);
    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const analysis = await storage.getLatestAnalysis(id);
    if (!analysis) {
      return res.status(404).json({ message: "No analysis yet" });
    }

    res.json(analysis);
  });

  app.post(api.resumes.analyze.path, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const resume = await storage.getResume(id);
    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    try {
      const body = api.resumes.analyze.input?.parse(req.body ?? undefined);
      const result = await analyzeResumeWithAI({
        resumeText: resume.resumeText,
        jobTitle: body?.jobTitle ?? resume.jobTitle,
        jobDescription: body?.jobDescription ?? resume.jobDescription,
      });

      const created = await storage.createAnalysis(id, result);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorTo400(err));
      }
      if (err instanceof SyntaxError) {
        return res.status(500).json({ message: "AI returned invalid output" });
      }
      throw err;
    }
  });

  return httpServer;
}
