import { eq, desc, ilike } from "drizzle-orm";
import { db } from "./db";
import {
  resumes,
  resumeAnalyses,
  type ResumeResponse,
  type ResumeListResponse,
  type CreateResumeRequest,
  type UpdateResumeRequest,
  type ResumeAnalysisResponse,
  type ResumeAnalysisResult,
} from "@shared/schema";

export interface IStorage {
  listResumes(search?: string): Promise<ResumeListResponse>;
  getResume(id: number): Promise<ResumeResponse | undefined>;
  createResume(input: CreateResumeRequest): Promise<ResumeResponse>;
  updateResume(id: number, updates: UpdateResumeRequest): Promise<ResumeResponse | undefined>;
  deleteResume(id: number): Promise<boolean>;

  createAnalysis(resumeId: number, result: ResumeAnalysisResult): Promise<ResumeAnalysisResponse>;
  getLatestAnalysis(resumeId: number): Promise<ResumeAnalysisResponse | undefined>;
}

export class DatabaseStorage implements IStorage {
  async listResumes(search?: string): Promise<ResumeListResponse> {
    if (search && search.trim()) {
      return db
        .select()
        .from(resumes)
        .where(ilike(resumes.title, `%${search.trim()}%`))
        .orderBy(desc(resumes.createdAt));
    }

    return db.select().from(resumes).orderBy(desc(resumes.createdAt));
  }

  async getResume(id: number): Promise<ResumeResponse | undefined> {
    const [row] = await db.select().from(resumes).where(eq(resumes.id, id));
    return row;
  }

  async createResume(input: CreateResumeRequest): Promise<ResumeResponse> {
    const [row] = await db.insert(resumes).values(input).returning();
    return row;
  }

  async updateResume(
    id: number,
    updates: UpdateResumeRequest,
  ): Promise<ResumeResponse | undefined> {
    const [row] = await db
      .update(resumes)
      .set(updates)
      .where(eq(resumes.id, id))
      .returning();
    return row;
  }

  async deleteResume(id: number): Promise<boolean> {
    const deleted = await db.delete(resumes).where(eq(resumes.id, id)).returning();
    return deleted.length > 0;
  }

  async createAnalysis(
    resumeId: number,
    result: ResumeAnalysisResult,
  ): Promise<ResumeAnalysisResponse> {
    const [row] = await db
      .insert(resumeAnalyses)
      .values({
        resumeId,
        overallScore: Math.max(0, Math.min(100, Math.trunc(result.overallScore))),
        summary: result.summary,
        strengths: result.strengths,
        gaps: result.gaps,
        improvements: result.improvements,
        atsKeywords: result.atsKeywords,
        missingKeywords: result.missingKeywords,
        redFlags: result.redFlags,
        sectionsScore: result.sectionsScore,
      })
      .returning();
    return row;
  }

  async getLatestAnalysis(resumeId: number): Promise<ResumeAnalysisResponse | undefined> {
    const [row] = await db
      .select()
      .from(resumeAnalyses)
      .where(eq(resumeAnalyses.resumeId, resumeId))
      .orderBy(desc(resumeAnalyses.createdAt))
      .limit(1);
    return row;
  }
}

export const storage = new DatabaseStorage();
